#!/bin/bash

echo "build ..."
if [ "local_bundle_mock" = $1 ] ; then
    mvn clean package -pl MavenTest-bundle-mock -am -Dbdmgc.skip=false -Dcodeg.author=fastjrun
elif [ "provider_mock" = $1 ] ; then
    mvn clean package -pl MavenTest-provider-mock -am -Dbdmgc.skip=false -Dcodeg.author=fastjrun
    cp MavenTest-provider-mock/target/MavenTest-provider-mock.war ~/server/tomcat8/webapps/MavenTest-provider-mock.war
elif [ "package_api_test" = $1 ] ; then
    mvn clean package -pl MavenTest-api-test -am -Dclientgc.skip=false -Dcodeg.author=fastjrun
elif [ "unitTest" = $1 ] ; then
    mvn clean verify -pl MavenTest-test -PunitTest -am
elif [ "mock_test" = $1 ] ; then
    mvn clean package -pl MavenTest-api-test -Dclientgc.skip=false -Dcodeg.author=fastjrun -Pmock
elif [ "package_provider" = $1 ] ; then
    mvn clean package -pl MavenTest-provider -am -Dbasegc.skip=false -Dbdgc.skip=false -Dcodeg.author=fastjrun -P$2
    cp MavenTest-provider/target/MavenTest-provider.war ~/server/tomcat8/webapps/MavenTest-provider.war
elif [ "api_test" = $1 ] ; then
    mvn clean package -pl MavenTest-api-test -Dclientgc.skip=false -Dcodeg.author=fastjrun -P$2
elif [ "package_task" = $1 ] ; then
    mvn clean package -pl MavenTest-task -am -Dbasegc.skip=false -Dbdgc.skip=false -Dcodeg.author=fastjrun -P$2
    rm -rf ~/app/MavenTest/MavenTest-task
    cp -r MavenTest-task/target/MavenTest-task/MavenTest-task ~/app/MavenTest/MavenTest-task
elif [ "package_ci" = $1 ] ; then
    mvn clean package -pl MavenTest-base -am -Dbasegc.skip=false -Dcodeg.author=fastjrun
    mvn clean package -pl MavenTest-bundle -am -Dbdgc.skip=false -Dcodeg.author=fastjrun
    mvn clean package -pl MavenTest-api-test -am -Dclientgc.skip=false -Dcodeg.author=fastjrun -Dmaven.test.skip=true
    mvn clean package -pl MavenTest-bundle-mock -am -Dbdmgc.skip=false -Dcodeg.author=fastjrun
    mvn clean package -pl MavenTest-api -am -Dapigc.skip=false -Dcodeg.author=fastjrun
elif [ "service_ut" = $1 ] ; then
    mvn clean package -pl MavenTest-test -am -Dbasegc.skip=false -Dbdgc.skip=false -Dcodeg.author=fastjrun -P$2
fi
echo "build done."