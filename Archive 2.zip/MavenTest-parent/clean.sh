#!/bin/bash

echo "clean ..."
# rm MavenTest-api
rm -rf MavenTest-api/src/

# rm MavenTest-api-test
rm -rf MavenTest-api-test/src/main/
rm -rf MavenTest-api-test/src/test/java/
rm -rf MavenTest-api-test/src/test/resources/testng.xml
rm -rf MavenTest-api-test/src/test/data/

# rm MavenTest-base
rm -rf MavenTest-base/src/

# rm MavenTest-api
rm -rf MavenTest-api/src/

# rm MavenTest-bundle
rm -rf MavenTest-bundle/src/

# rm MavenTest-bundle-mock
rm -rf MavenTest-bundle-mock/src/

mvn clean
echo "clean done."