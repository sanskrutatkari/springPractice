package helloWorld;

public class Implements {
	public static void main(String srgs[]) {
		HelloWorld h = new HelloWorld();
		h.hello();
	}
}
