package helloWorld;

public class HelloWorld extends World{
	
	public void hello() {
		System.out.println("HelloWorld");
	}
}
