package helloWorld;

public class World {
	public void hello() {
		System.out.println("Hello");
	}
}
