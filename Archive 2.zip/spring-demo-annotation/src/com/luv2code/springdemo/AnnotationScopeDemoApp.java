package com.luv2code.springdemo;

import org.springframework.context.support.ClassPathXmlApplicationContext;

public class AnnotationScopeDemoApp {

	public static void main(String[] args) {
		//create spring container
		ClassPathXmlApplicationContext context = 
				new ClassPathXmlApplicationContext("applicationContext.xml");
		//retrieve bean
		
		Coach theCoach = context.getBean("tennisCoach", Coach.class);
		
		Coach alphaCoach = context.getBean("tennisCoach", Coach.class);
		
		//check
		boolean isSame = (theCoach == alphaCoach);
		
		System.out.println("Both beans requested are same: "+ isSame);
		
		System.out.println("Address of 1st bean: "+ theCoach);
		
		System.out.println("Address of 2nd bean:"+ alphaCoach);
		
		//close container

		context.close();
	}

}
