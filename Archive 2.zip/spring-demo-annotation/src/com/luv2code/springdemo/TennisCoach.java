package com.luv2code.springdemo;

import javax.annotation.PostConstruct;
import javax.annotation.PreDestroy;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

@Component
public class TennisCoach implements Coach {

	@Autowired
	@Qualifier("randomFortuneService")
	private FortuneService fortuneService;
	//define default constructor
	
	public TennisCoach() {
		System.out.println("Inside >> the default constructor..");
	}
	/*
	@Autowired
	public TennisCoach(FortuneService fortuneService) {
		this.fortuneService = fortuneService;
	}*/
	
	/*
	@Autowired
	public void doSomeCrazzyStuff(FortuneService fortuneService) {
		
		System.out.println("Inside >> the doSomeCrazzyStuff() method..");
		this.fortuneService = fortuneService;
		
	}*/	
	
	//define init method
	@PostConstruct
	public void doMyStartUpStuff() {
		System.out.println("inside the init method");
	}
	
	//define destroy method
	@PreDestroy
	public void doMyWrapUpStuff() {
		System.out.println("inside the destroy method");
	}
	
	@Override
	public String getDailyWorkout() {
		return "Do service practice";
	}

	@Override
	public String getDailyFortune() {
		return fortuneService.getDailyFortune();
	}

}
