package com.luv2code.springdemo;

import java.util.Random;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

@Component
public class RandomFortuneService implements FortuneService {
	

	@Value("${arrayOfFortunes}")
	private String[] fortunes;
	
	private Random random = new Random();
	
	@Override
	public String getDailyFortune() {
		int index = random.nextInt(fortunes.length);
		return fortunes[index];
	}

}
