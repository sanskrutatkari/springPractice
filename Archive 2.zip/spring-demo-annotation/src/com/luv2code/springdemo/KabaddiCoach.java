package com.luv2code.springdemo;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Component;

@Component
public class KabaddiCoach implements Coach {

	@Autowired
	@Qualifier("goodFortuneService")
	FortuneService fortuneService;
	
	@Override
	public String getDailyWorkout() {
		return "Do raid practice";
	}

	@Override
	public String getDailyFortune() {
		return fortuneService.getDailyFortune();
	}

}
